import { Link, useParams } from 'react-router-dom';
import { ChevronRight, ExternalLink, Map, MapPin, Navigation } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import ImageCarousel from '@/components/places/ImageCarousel';
import Highlights from '@/components/places/Highlights';
import PlaceCard from '@/components/places/PlaceCard';
import { ErrorState } from '@/components/common/StateViews';
import RouteFallback from '@/components/common/RouteFallback';
import NotFound from '@/pages/NotFound';
import { usePlaces } from '@/context/PlacesContext';
import usePageTitle from '@/hooks/usePageTitle';
import useLocalized from '@/hooks/useLocalized';
import { CATEGORIES, ROUTES } from '@/config/routes';
import { splitParagraphs } from '@/lib/text';

function directionsUrl({ lat, lng }) {
  return `https://www.google.com/maps/search/?api=1&query=${lat},${lng}`;
}

export default function PlaceDetail() {
  const { slug } = useParams();
  const { t } = useTranslation();
  const { l } = useLocalized();
  const { status, places, reload, getBySlug, byCategory } = usePlaces();

  const place = getBySlug(slug);
  usePageTitle(place ? l(place.name) : undefined);

  if (!place) {
    if (status === 'loading') return <RouteFallback />;
    if (status === 'error' && places.length === 0) {
      return (
        <div className="container-page">
          <ErrorState onRetry={reload} />
        </div>
      );
    }
    return <NotFound />;
  }

  const name = l(place.name);
  const category = CATEGORIES.find((c) => c.key === place.category);
  const related = byCategory(place.category)
    .filter((item) => item.slug !== place.slug)
    .slice(0, 3);
  const highlights = l(place.highlights);

  return (
    <article>
      {/* Tiêu đề trang */}
      <header className="hero-bg border-b">
        <div className="container-page py-10 sm:py-14">
          <nav aria-label={t('place.breadcrumb')} className="flex flex-wrap items-center gap-1.5 text-sm text-muted">
            <Link to={ROUTES.home} className="hover:text-brand">
              {t('nav.home')}
            </Link>
            <ChevronRight className="h-4 w-4" aria-hidden="true" />
            {category && (
              <>
                <Link to={category.path} className="hover:text-brand">
                  {t(`nav.${category.key}`)}
                </Link>
                <ChevronRight className="h-4 w-4" aria-hidden="true" />
              </>
            )}
            <span aria-current="page" className="text-fg">
              {name}
            </span>
          </nav>

          <h1 className="mt-5 max-w-4xl text-4xl leading-tight sm:text-5xl">{name}</h1>
          <p className="mt-4 max-w-3xl text-lg text-muted">{l(place.summary)}</p>
        </div>
      </header>

      <div className="container-page py-10 sm:py-14">
        {/* Ảnh nổi bật: băng chuyền + Lightbox */}
        <ImageCarousel images={place.images} name={name} />

        <div className="mt-12 grid gap-12 lg:grid-cols-[1fr_340px]">
          {/* Nội dung chính */}
          <div>
            <section aria-labelledby="about-title">
              <h2 id="about-title" className="text-2xl sm:text-3xl">
                {t('place.about')}
              </h2>
              <div className="mt-5 space-y-5 text-[17px] leading-8 text-fg/90">
                {splitParagraphs(l(place.description)).map((paragraph, index) => (
                  <p key={index}>{paragraph}</p>
                ))}
              </div>
            </section>

            <Highlights items={highlights} />
          </div>

          {/* Thông tin tổng quan */}
          <aside aria-labelledby="overview-title" className="lg:sticky lg:top-28 lg:self-start">
            <div className="rounded-3xl border bg-surface p-6 shadow-card">
              <h2 id="overview-title" className="text-xl">
                {t('place.overview')}
              </h2>

              <dl className="mt-5 space-y-5 text-sm">
                <div className="flex gap-3">
                  <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-brand/10 text-brand">
                    <MapPin className="h-5 w-5" aria-hidden="true" />
                  </span>
                  <div>
                    <dt className="font-semibold">{t('place.address')}</dt>
                    <dd className="mt-1 leading-relaxed text-muted">{l(place.address)}</dd>
                  </div>
                </div>

                {category && (
                  <div className="flex gap-3">
                    <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-accent/15 text-accent">
                      <Navigation className="h-5 w-5" aria-hidden="true" />
                    </span>
                    <div>
                      <dt className="font-semibold">{t('place.category')}</dt>
                      <dd className="mt-1">
                        <Link to={category.path} className="text-muted hover:text-brand">
                          {t(`nav.${category.key}`)}
                        </Link>
                      </dd>
                    </div>
                  </div>
                )}
              </dl>

              {place.coordinates && (
                <div className="mt-6 flex flex-col gap-3">
                  <Link to={`${ROUTES.map}?place=${encodeURIComponent(place.slug)}`} className="btn btn-primary">
                    <Map className="h-4 w-4" aria-hidden="true" />
                    {t('place.viewOnMap')}
                  </Link>
                  <a
                    href={directionsUrl(place.coordinates)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn btn-outline"
                  >
                    <ExternalLink className="h-4 w-4" aria-hidden="true" />
                    {t('place.directions')}
                  </a>
                </div>
              )}
            </div>
          </aside>
        </div>

        {related.length > 0 && (
          <section aria-labelledby="related-title" className="mt-20">
            <h2 id="related-title" className="text-2xl sm:text-3xl">
              {t('place.related')}
            </h2>
            <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {related.map((item, index) => (
                <PlaceCard key={item.slug} place={item} index={index} />
              ))}
            </div>
          </section>
        )}
      </div>
    </article>
  );
}
