import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';
import vi from './locales/vi.json';
import en from './locales/en.json';

export const SUPPORTED_LANGUAGES = ['vi', 'en'];
export const DEFAULT_LANGUAGE = 'vi';

// Đồng bộ <html lang>, <title> và meta description mỗi khi đổi ngôn ngữ.
// Đăng ký trước init() để sự kiện đầu tiên (lúc khởi tạo) cũng được bắt.
function syncDocument() {
  const lang = i18n.resolvedLanguage || DEFAULT_LANGUAGE;
  document.documentElement.lang = lang;
  document.title = i18n.t('meta.title');

  const description = document.querySelector('meta[name="description"]');
  if (description) description.setAttribute('content', i18n.t('meta.description'));
}

i18n.on('languageChanged', syncDocument);

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources: {
      vi: { translation: vi },
      en: { translation: en },
    },
    supportedLngs: SUPPORTED_LANGUAGES,
    fallbackLng: DEFAULT_LANGUAGE,
    nonExplicitSupportedLngs: true, // en-US, en-GB -> en
    load: 'languageOnly',
    initImmediate: false, // nạp đồng bộ để lần render đầu tiên không bị hiện key
    interpolation: { escapeValue: false }, // React đã tự escape
    detection: {
      order: ['localStorage', 'navigator'],
      lookupLocalStorage: 'lang',
      caches: ['localStorage'],
    },
    react: { useSuspense: false },
  });

export default i18n;
