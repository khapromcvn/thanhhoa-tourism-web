// Thông tin liên hệ và mạng xã hội. Ghi đè bằng biến môi trường VITE_* (xem client/.env.example).

const env = import.meta.env;

export const SITE = {
  email: env.VITE_CONTACT_EMAIL || 'contact@example.com',
  phone: env.VITE_CONTACT_PHONE || '+84 900 000 000',
};

export const SOCIALS = [
  { key: 'facebook', label: 'Facebook', href: env.VITE_SOCIAL_FACEBOOK || 'https://www.facebook.com/' },
  { key: 'youtube', label: 'YouTube', href: env.VITE_SOCIAL_YOUTUBE || 'https://www.youtube.com/' },
  { key: 'instagram', label: 'Instagram', href: env.VITE_SOCIAL_INSTAGRAM || 'https://www.instagram.com/' },
];
