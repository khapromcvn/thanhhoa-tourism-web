import { useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import { localize } from '@/lib/text';

// Trả về ngôn ngữ hiện tại và hàm l(field) để lấy nội dung song ngữ của địa điểm.
export default function useLocalized() {
  const { i18n } = useTranslation();
  const lang = i18n.resolvedLanguage === 'en' ? 'en' : 'vi';
  const l = useCallback((field) => localize(field, lang), [lang]);
  return { lang, l };
}
