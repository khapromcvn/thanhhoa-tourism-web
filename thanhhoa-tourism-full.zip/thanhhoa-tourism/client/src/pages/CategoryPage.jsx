import { useTranslation } from 'react-i18next';
import PageHero from '@/components/common/PageHero';
import PlaceGrid from '@/components/places/PlaceGrid';
import { usePlaces } from '@/context/PlacesContext';
import usePageTitle from '@/hooks/usePageTitle';

// Dùng chung cho Du lịch / Ẩm thực / Văn hóa. `category` là khóa i18n: categories.<category>.*
export default function CategoryPage({ category }) {
  const { t } = useTranslation();
  const { status, reload, byCategory } = usePlaces();
  const title = t(`categories.${category}.title`);
  usePageTitle(title);

  return (
    <>
      <PageHero
        eyebrow={t(`categories.${category}.eyebrow`)}
        title={title}
        subtitle={t(`categories.${category}.subtitle`)}
      />
      <section className="container-page py-14 sm:py-20">
        <PlaceGrid places={byCategory(category)} status={status} onRetry={reload} />
      </section>
    </>
  );
}
