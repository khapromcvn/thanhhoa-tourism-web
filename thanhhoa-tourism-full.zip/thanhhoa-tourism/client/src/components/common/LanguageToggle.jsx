import { useTranslation } from 'react-i18next';
import { FlagGB, FlagVN } from './Flags';

const LANGUAGES = [
  { code: 'vi', label: 'VN', Flag: FlagVN },
  { code: 'en', label: 'EN', Flag: FlagGB },
];

export default function LanguageToggle() {
  const { t, i18n } = useTranslation();
  const current = i18n.resolvedLanguage === 'en' ? 'en' : 'vi';

  return (
    <div
      role="group"
      aria-label={t('header.language')}
      className="relative grid grid-cols-2 rounded-full border bg-surface p-0.5"
    >
      {/* Nút trượt nền, chuyển động mượt khi đổi ngôn ngữ */}
      <span
        aria-hidden="true"
        className={`absolute inset-y-0.5 left-0.5 w-[calc(50%-2px)] rounded-full bg-brand shadow-sm transition-transform duration-300 ease-out ${
          current === 'en' ? 'translate-x-full' : 'translate-x-0'
        }`}
      />
      {LANGUAGES.map(({ code, label, Flag }) => {
        const active = current === code;
        return (
          <button
            key={code}
            type="button"
            onClick={() => i18n.changeLanguage(code)}
            aria-pressed={active}
            aria-label={label}
            className={`relative z-10 flex h-8 items-center justify-center gap-1.5 rounded-full px-2.5 text-xs font-semibold transition-colors duration-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand ${
              active ? 'text-brand-fg' : 'text-muted hover:text-fg'
            }`}
          >
            <Flag className="h-3.5 w-5 rounded-[2px] shadow-[0_0_0_1px_rgb(0_0_0/0.15)]" />
            <span className="hidden sm:inline">{label}</span>
          </button>
        );
      })}
    </div>
  );
}
