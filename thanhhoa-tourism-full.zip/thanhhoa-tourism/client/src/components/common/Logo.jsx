import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { ROUTES } from '@/config/routes';

export default function Logo({ className = '' }) {
  const { t } = useTranslation();

  return (
    <Link
      to={ROUTES.home}
      aria-label={`${t('brand.name')} — ${t('nav.home')}`}
      className={`group inline-flex items-center gap-2.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand focus-visible:ring-offset-2 focus-visible:ring-offset-bg rounded-xl ${className}`}
    >
      <span className="grid h-9 w-9 place-items-center rounded-xl bg-brand text-brand-fg shadow-soft transition-transform duration-300 group-hover:-rotate-6">
        <svg
          viewBox="0 0 24 24"
          className="h-5 w-5"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeLinejoin="round"
          aria-hidden="true"
        >
          <path d="M3 19 9.5 8l3.5 6 2-3L21 19Z" />
          <circle cx="17" cy="6" r="1.6" />
        </svg>
      </span>
      <span className="flex flex-col leading-none">
        <span className="font-display text-lg font-semibold tracking-tight text-fg">
          {t('brand.name')}
        </span>
        <span className="mt-1 hidden text-[10px] font-semibold uppercase tracking-[0.22em] text-muted sm:block">
          {t('brand.tagline')}
        </span>
      </span>
    </Link>
  );
}
